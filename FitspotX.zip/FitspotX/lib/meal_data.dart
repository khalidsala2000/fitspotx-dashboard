class MealEntry {
  final String mealType;
  final String foodName;
  final double quantity;
  final String unit; // أضف الوحدة هون!
  final double calories;
  final double protein;
  final double carbs;
  final double fats;

  // إضافات جديدة
  final double saturatedFat;
  final double sugar;
  final double fiber;
  final double calcium;
  final double iron;
  final double magnesium;
  final double zinc;
  final double vitaminA;
  final double vitaminC;

  MealEntry({
    required this.mealType,
    required this.foodName,
    required this.quantity,
    required this.unit, // خليها required
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fats,
    required this.saturatedFat,
    required this.sugar,
    required this.fiber,
    required this.calcium,
    required this.iron,
    required this.magnesium,
    required this.zinc,
    required this.vitaminA,
    required this.vitaminC,
  });

  Map<String, dynamic> toJson() => {
        'mealType': mealType,
        'foodName': foodName,
        'quantity': quantity,
        'unit': unit,
        'calories': calories,
        'protein': protein,
        'carbs': carbs,
        'fats': fats,
        'saturatedFat': saturatedFat,
        'sugar': sugar,
        'fiber': fiber,
        'calcium': calcium,
        'iron': iron,
        'magnesium': magnesium,
        'zinc': zinc,
        'vitaminA': vitaminA,
        'vitaminC': vitaminC,
      };

  factory MealEntry.fromJson(Map<String, dynamic> json) => MealEntry(
        mealType: json['mealType'],
        foodName: json['foodName'],
        quantity: (json['quantity'] ?? 0).toDouble(),
        unit: json['unit'] ?? 'غرام', // افتراضي غرام إذا مش محدد
        calories: (json['calories'] ?? 0).toDouble(),
        protein: (json['protein'] ?? 0).toDouble(),
        carbs: (json['carbs'] ?? 0).toDouble(),
        fats: (json['fats'] ?? 0).toDouble(),
        saturatedFat: (json['saturatedFat'] ?? 0).toDouble(),
        sugar: (json['sugar'] ?? 0).toDouble(),
        fiber: (json['fiber'] ?? 0).toDouble(),
        calcium: (json['calcium'] ?? 0).toDouble(),
        iron: (json['iron'] ?? 0).toDouble(),
        magnesium: (json['magnesium'] ?? 0).toDouble(),
        zinc: (json['zinc'] ?? 0).toDouble(),
        vitaminA: (json['vitaminA'] ?? 0).toDouble(),
        vitaminC: (json['vitaminC'] ?? 0).toDouble(),
      );
}

// القائمة المؤقتة
List<MealEntry> mealsList = [];
