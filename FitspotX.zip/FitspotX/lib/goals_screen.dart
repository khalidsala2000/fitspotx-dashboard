import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'edit_goals_screen.dart';

class GoalsScreen extends StatefulWidget {
  const GoalsScreen({super.key});

  @override
  State<GoalsScreen> createState() => _GoalsScreenState();
}

class _GoalsScreenState extends State<GoalsScreen> {
  double calorieTarget = 2200;
  double calorieConsumed = 1800;
  int stepsTarget = 10000;
  int stepsTaken = 6000;
  double weightTarget = 80;
  double currentWeight = 75;

  @override
  void initState() {
    super.initState();
    loadGoals();
  }

  Future<void> loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      calorieTarget = prefs.getDouble('calorieTarget') ?? 2200;
      calorieConsumed = prefs.getDouble('calorieConsumed') ?? 1800;
      stepsTarget = prefs.getInt('stepsTarget') ?? 10000;
      stepsTaken = prefs.getInt('stepsTaken') ?? 6000;
      weightTarget = prefs.getDouble('weightTarget') ?? 80;
      currentWeight = prefs.getDouble('currentWeight') ?? 75;
    });
  }

  @override
  Widget build(BuildContext context) {
    double calorieProgress = calorieConsumed / calorieTarget;
    double stepsProgress = stepsTaken / stepsTarget;
    double weightProgress = currentWeight / weightTarget;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'أهدافي',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم رجوع أبيض موحد
          ),
          elevation: 0,
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GoalTile(
              title: 'السعرات اليومية',
              value: '${calorieConsumed.toInt()} / ${calorieTarget.toInt()} سعرة حرارية',
              progress: calorieProgress,
            ),
            GoalTile(
              title: 'عدد الخطوات',
              value: '$stepsTaken / $stepsTarget خطوة',
              progress: stepsProgress,
            ),
            GoalTile(
              title: 'الوزن الحالي',
              value: '$currentWeight كغ ← الهدف: $weightTarget كغ',
              progress: weightProgress,
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const EditGoalsScreen()),
                  );
                  await loadGoals(); // تحديث القيم بعد الرجوع
                },
                icon: const Icon(Icons.edit, color: Colors.white),
                label: const Text('تعديل الأهداف', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2CB191),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, fontFamily: 'Tajawal'),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GoalTile extends StatelessWidget {
  final String title;
  final String value;
  final double progress;

  const GoalTile({
    super.key,
    required this.title,
    required this.value,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF192734), fontFamily: 'Tajawal')),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(fontSize: 16, color: Color(0xFF192734), fontFamily: 'Tajawal')),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress.clamp(0.0, 1.0),
              minHeight: 10,
              backgroundColor: Colors.grey[300],
              color: const Color(0xFF2CB191),
            ),
          ],
        ),
      ),
    );
  }
}
