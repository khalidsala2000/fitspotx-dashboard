import 'package:flutter/material.dart';
import 'meals.dart'; // ملف الوجبات الثابتة
import 'food_entry.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class MealsScreen extends StatefulWidget {
  const MealsScreen({super.key});
  @override
  _MealsScreenState createState() => _MealsScreenState();
}

class _MealsScreenState extends State<MealsScreen> {
  String searchQuery = '';
  String selectedMealType = 'any';
  String selectedCaloriesRange = 'any';
  String selectedProteinRange = 'any';
  String selectedPrep = 'any';
  String selectedDiet = 'any';

  late BannerAd _bannerAd;
  bool _isBannerAdReady = false;

  @override
  void initState() {
    super.initState();
    _bannerAd = BannerAd(
adUnitId: 'ca-app-pub-3940256099942544/6300978111', // هذا الـ test ID الرسمي من Google للبانر
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdReady = true),
        onAdFailedToLoad: (_, __) => setState(() => _isBannerAdReady = false),
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    super.dispose();
  }

  List<Meal> getFilteredMeals() {
    return allMeals.where((meal) {
      bool matchesSearch = meal.title.contains(searchQuery);
      bool matchesMealType = selectedMealType == 'any' || meal.type == selectedMealType;
      bool matchesCalories = _matchesCalories(meal.calories.toDouble());
      bool matchesProtein = _matchesProtein(meal.protein.toDouble());
      bool matchesPrep = selectedPrep == 'any' || meal.prep == selectedPrep;
      bool matchesDiet = selectedDiet == 'any' || meal.diet == selectedDiet;
      return matchesSearch && matchesMealType && matchesCalories && matchesProtein && matchesPrep && matchesDiet;
    }).toList();
  }

  bool _matchesCalories(double calories) {
    switch (selectedCaloriesRange) {
      case 'lt100': return calories < 100;
      case '100-200': return calories >= 100 && calories < 200;
      case '200-300': return calories >= 200 && calories < 300;
      case '300-400': return calories >= 300 && calories < 400;
      case '400-500': return calories >= 400 && calories < 500;
      case 'gt500': return calories >= 500;
      default: return true;
    }
  }

  bool _matchesProtein(double protein) {
    switch (selectedProteinRange) {
      case 'lt10': return protein < 10;
      case '10-20': return protein >= 10 && protein < 20;
      case '20-30': return protein >= 20 && protein < 30;
      case '30-40': return protein >= 30 && protein < 40;
      case 'gt40': return protein >= 40;
      default: return true;
    }
  }

  String getArabicMealType(String type) {
    switch (type) {
      case 'breakfast': return 'فطور';
      case 'lunch': return 'غداء';
      case 'dinner': return 'عشاء';
      case 'snack': return 'سناك';
      case 'any': return 'أي وجبة';
      default: return type;
    }
  }

  String getArabicPrep(String prep) {
    switch (prep) {
      case 'before': return 'قبل الطبخ';
      case 'after': return 'بعد الطبخ';
      case 'none': return 'غير محدد';
      case 'any': return 'أي طريقة';
      default: return prep;
    }
  }

  String getArabicDiet(String diet) {
    switch (diet) {
      case 'vegan': return 'نباتي بحت';
      case 'vegetarian': return 'نباتي';
      case 'non-veg': return 'غير نباتي';
      case 'any': return 'أي نظام';
      default: return diet;
    }
  }

  String _getCaloriesRangeLabel(String range) {
    switch (range) {
      case 'lt100': return 'أقل من 100';
      case '100-200': return '100 - 200';
      case '200-300': return '200 - 300';
      case '300-400': return '300 - 400';
      case '400-500': return '400 - 500';
      case 'gt500': return 'أكثر من 500';
      case 'any': return 'أي كمية';
      default: return range;
    }
  }

  String _getProteinRangeLabel(String range) {
    switch (range) {
      case 'lt10': return 'أقل من 10غ';
      case '10-20': return '10 - 20غ';
      case '20-30': return '20 - 30غ';
      case '30-40': return '30 - 40غ';
      case 'gt40': return 'أكثر من 40غ';
      case 'any': return 'أي كمية';
      default: return range;
    }
  }

  Widget _styledDropdown({
    required String value,
    required void Function(String?) onChanged,
    required List<String> items,
    required String Function(String) labelBuilder,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF192734), width: 1),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButton<String>(
        isExpanded: true,
        value: value,
        icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF2CB191)),
        underline: const SizedBox(),
        onChanged: onChanged,
        items: items.map((String val) {
          return DropdownMenuItem<String>(
            value: val,
            child: Text(labelBuilder(val)),
          );
        }).toList(),
      ),
    );
  }

  // دالة إضافة الوجبة ليوم المستخدم
  Future<void> _addMealToDay(Meal meal, BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> saved = prefs.getStringList('foodEntries') ?? [];

    final food = FoodEntry(
      mealType: getArabicMealType(meal.type),
      foodName: meal.title,
      quantity: 1,
      unit: 'حصة',
      calories: (meal.calories ?? 0).toDouble(),
      protein: (meal.protein ?? 0).toDouble(),
      carbs: (meal.carbs ?? 0).toDouble(),
      fats: (meal.fat ?? 0).toDouble(),
      saturatedFat: 0,
      sugar: 0,
      fiber: 0,
      calcium: 0,
      iron: 0,
      magnesium: 0,
      zinc: 0,
      vitaminA: 0,
      vitaminC: 0,
    );

    saved.add(jsonEncode(food.toJson()));
    await prefs.setStringList('foodEntries', saved);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تمت إضافة الوجبة ليومك!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F9FA),
        appBar: AppBar(
          title: const Text('الوجبات المحسوبة'),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          backgroundColor: const Color(0xFF2CB191),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        body: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // البحث
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF192734), width: 1),
                      ),
                      child: TextField(
                        decoration: const InputDecoration(
                          labelText: 'ابحث عن الوجبة',
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          prefixIcon: Icon(Icons.search, color: Color(0xFF2CB191)),
                        ),
                        onChanged: (value) {
                          setState(() {
                            searchQuery = value;
                          });
                        },
                      ),
                    ),
                    const SizedBox(height: 10),
                    // الفلاتر
                    Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('الفلاتر', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF192734))),
                            const SizedBox(height: 8),
                            const Text('نوع الوجبة', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                            _styledDropdown(
                              value: selectedMealType,
                              onChanged: (val) => setState(() => selectedMealType = val!),
                              items: ['any', 'breakfast', 'lunch', 'dinner', 'snack'],
                              labelBuilder: getArabicMealType,
                            ),
                            const SizedBox(height: 10),
                            const Text('كمية السعرات', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                            _styledDropdown(
                              value: selectedCaloriesRange,
                              onChanged: (val) => setState(() => selectedCaloriesRange = val!),
                              items: ['any', 'lt100', '100-200', '200-300', '300-400', '400-500', 'gt500'],
                              labelBuilder: _getCaloriesRangeLabel,
                            ),
                            const SizedBox(height: 10),
                            const Text('كمية البروتين', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                            _styledDropdown(
                              value: selectedProteinRange,
                              onChanged: (val) => setState(() => selectedProteinRange = val!),
                              items: ['any', 'lt10', '10-20', '20-30', '30-40', 'gt40'],
                              labelBuilder: _getProteinRangeLabel,
                            ),
                            const SizedBox(height: 10),
                            const Text('حالة الطبخ', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                            _styledDropdown(
                              value: selectedPrep,
                              onChanged: (val) => setState(() => selectedPrep = val!),
                              items: ['any', 'before', 'after', 'none'],
                              labelBuilder: getArabicPrep,
                            ),
                            const SizedBox(height: 10),
                            const Text('النظام الغذائي', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                            _styledDropdown(
                              value: selectedDiet,
                              onChanged: (val) => setState(() => selectedDiet = val!),
                              items: ['any', 'vegan', 'vegetarian', 'non-veg'],
                              labelBuilder: getArabicDiet,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // عرض الوجبات
                    Expanded(
                      child: getFilteredMeals().isEmpty
                          ? const Center(
                              child: Text(
                                'لا يوجد وجبات مطابقة للبحث أو الفلاتر.',
                                style: TextStyle(color: Color(0xFF192734)),
                              ),
                            )
                          : ListView.builder(
                              itemCount: getFilteredMeals().length,
                              itemBuilder: (context, index) {
                                final meal = getFilteredMeals()[index];
                                return Card(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    side: const BorderSide(
                                      color: Color(0xFF192734),
                                      width: 1,
                                    ),
                                  ),
                                  elevation: 0,
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                meal.title,
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16,
                                                  color: Color(0xFF2CB191),
                                                ),
                                              ),
                                            ),
                                            IconButton(
                                              icon: const Icon(Icons.add_circle, color: Color(0xFF2CB191), size: 28),
                                              tooltip: 'إضافة لليومي',
                                              onPressed: () async {
                                                await _addMealToDay(meal, context);
                                              },
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          '${meal.calories} سعرة حرارية | بروتين: ${meal.protein}غ | كارب: ${meal.carbs}غ | دهون: ${meal.fat}غ',
                                          style: const TextStyle(fontSize: 13, color: Color(0xFF192734)),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          'النوع: ${getArabicMealType(meal.type)}',
                                          style: const TextStyle(fontSize: 13, color: Colors.black54),
                                        ),
                                        if (meal.details.isNotEmpty) ...[
                                          const SizedBox(height: 4),
                                          Text(
                                            'المكونات: ${meal.details}',
                                            style: const TextStyle(fontSize: 12),
                                          ),
                                        ],
                                        if (meal.notes.isNotEmpty) ...[
                                          const SizedBox(height: 4),
                                          Text(
                                            'ملاحظات: ${meal.notes.join(", ")}',
                                            style: const TextStyle(fontSize: 11, color: Colors.teal),
                                          ),
                                        ],
                                        const SizedBox(height: 4),
                                        Text(
                                          'التحضير: ${getArabicPrep(meal.prep)}  |  النظام الغذائي: ${getArabicDiet(meal.diet)}',
                                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            ),
            // إعلان البانر
            if (_isBannerAdReady)
              SizedBox(
                height: _bannerAd.size.height.toDouble(),
                width: _bannerAd.size.width.toDouble(),
                child: AdWidget(ad: _bannerAd),
              ),
          ],
        ),
      ),
    );
  }
}
