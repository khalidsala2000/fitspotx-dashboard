import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditGoalsScreen extends StatefulWidget {
  const EditGoalsScreen({super.key});

  @override
  State<EditGoalsScreen> createState() => _EditGoalsScreenState();
}

class _EditGoalsScreenState extends State<EditGoalsScreen> {
  late TextEditingController calorieTargetCtrl;
  late TextEditingController stepsTargetCtrl;
  late TextEditingController weightTargetCtrl;

  @override
  void initState() {
    super.initState();
    calorieTargetCtrl = TextEditingController();
    stepsTargetCtrl = TextEditingController();
    weightTargetCtrl = TextEditingController();
    loadGoals();
  }

  Future<void> loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      calorieTargetCtrl.text = (prefs.getDouble('calorieTarget') ?? 2200).toStringAsFixed(0);
      stepsTargetCtrl.text = (prefs.getInt('stepsTarget') ?? 10000).toString();
      weightTargetCtrl.text = (prefs.getDouble('weightTarget') ?? 80).toStringAsFixed(1);
    });
  }

  Future<void> saveGoals() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('calorieTarget', double.tryParse(calorieTargetCtrl.text) ?? 2200);
    await prefs.setInt('stepsTarget', int.tryParse(stepsTargetCtrl.text) ?? 10000);
    await prefs.setDouble('weightTarget', double.tryParse(weightTargetCtrl.text) ?? 80);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'تعديل الأهداف',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم الرجوع أبيض
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              TextField(
                controller: calorieTargetCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'هدف السعرات الحرارية (س.ح)',
                  labelStyle: TextStyle(color: Color(0xFF2CB191)),
                  border: OutlineInputBorder(),
                  fillColor: Color(0xFFF7F9FA),
                  filled: true,
                ),
                style: const TextStyle(fontFamily: 'Tajawal', color: Color(0xFF192734)),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: stepsTargetCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'هدف عدد الخطوات',
                  labelStyle: TextStyle(color: Color(0xFF2CB191)),
                  border: OutlineInputBorder(),
                  fillColor: Color(0xFFF7F9FA),
                  filled: true,
                ),
                style: const TextStyle(fontFamily: 'Tajawal', color: Color(0xFF192734)),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: weightTargetCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'الوزن المستهدف (كغ)',
                  labelStyle: TextStyle(color: Color(0xFF2CB191)),
                  border: OutlineInputBorder(),
                  fillColor: Color(0xFFF7F9FA),
                  filled: true,
                ),
                style: const TextStyle(fontFamily: 'Tajawal', color: Color(0xFF192734)),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    await saveGoals();
                    if (mounted) Navigator.pop(context);
                  },
                  icon: const Icon(Icons.save, color: Colors.white),
                  label: const Text('حفظ الأهداف', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2CB191),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Tajawal'),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
