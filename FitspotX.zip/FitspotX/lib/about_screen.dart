import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'حول التطبيق',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم الرجوع أبيض دائمًا
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Center(
            child: Text(
              'تطبيق FitspotX هو رفيقك اليومي لتتبع التغذية والصحة والرياضة. هدفنا نوفر لك تجربة سهلة وبسيطة لمراقبة تقدمك وتحقيق أهدافك الصحية خطوة بخطوة!',
              style: const TextStyle(
                fontSize: 18,
                color: Color(0xFF192734),
                fontFamily: 'Tajawal',
                fontWeight: FontWeight.w500,
                height: 1.7,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}
