import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class WeightTrackerScreen extends StatefulWidget {
  const WeightTrackerScreen({Key? key}) : super(key: key);

  @override
  State<WeightTrackerScreen> createState() => _WeightTrackerScreenState();
}

class _WeightTrackerScreenState extends State<WeightTrackerScreen> {
  List<double> _weights = [];
  List<String> _dates = [];
  final TextEditingController _controller = TextEditingController();

  // --- Rewarded Ad ---
  RewardedAd? _rewardedAd;
  bool _isRewardedAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadWeights();
    _loadRewardedAd();
  }

  void _loadRewardedAd() {
    RewardedAd.load(
adUnitId: 'ca-app-pub-3940256099942544/6300978111', // هذا الـ test ID الرسمي من Google للبانر
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          setState(() {
            _rewardedAd = ad;
            _isRewardedAdLoaded = true;
          });
        },
        onAdFailedToLoad: (err) {
          setState(() {
            _rewardedAd = null;
            _isRewardedAdLoaded = false;
          });
        },
      ),
    );
  }

  void _showRewardedAd() {
    if (_rewardedAd != null) {
      _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          ad.dispose();
          _loadRewardedAd();
        },
        onAdFailedToShowFullScreenContent: (ad, err) {
          ad.dispose();
          _loadRewardedAd();
        },
      );
      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('شكرًا على دعمك 🙏')),
          );
        },
      );
      setState(() {
        _rewardedAd = null;
        _isRewardedAdLoaded = false;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _rewardedAd?.dispose();
    super.dispose();
  }

  Future<void> _loadWeights() async {
    final prefs = await SharedPreferences.getInstance();
    final weightsString = prefs.getString('weights') ?? '[]';
    final datesString = prefs.getString('dates') ?? '[]';
    setState(() {
      _weights = (jsonDecode(weightsString) as List).map((e) => e as double).toList();
      _dates = (jsonDecode(datesString) as List).map((e) => e as String).toList();
    });
  }

  Future<void> _saveWeights() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('weights', jsonEncode(_weights));
    await prefs.setString('dates', jsonEncode(_dates));
  }

  void _addWeight() async {
    final text = _controller.text;
    if (text.isEmpty) return;
    final weight = double.tryParse(text);
    if (weight == null) return;

    setState(() {
      _weights.add(weight);
      final now = DateTime.now();
      _dates.add("${now.month}/${now.day}");
      _controller.clear();
    });
    await _saveWeights();
  }

  void _showEditDialog(int idx) {
    _controller.text = _weights[idx].toString();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعديل الوزن'),
        content: TextField(
          controller: _controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'الوزن (كغ)'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2CB191)),
            onPressed: () async {
              final text = _controller.text;
              final weight = double.tryParse(text);
              if (weight != null) {
                setState(() {
                  _weights[idx] = weight;
                });
                await _saveWeights();
              }
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  void _deleteWeight(int idx) async {
    setState(() {
      _weights.removeAt(idx);
      _dates.removeAt(idx);
    });
    await _saveWeights();
  }

  List<FlSpot> getChartData() {
    return _weights.asMap().entries.map((entry) {
      return FlSpot(entry.key.toDouble(), entry.value);
    }).toList();
  }

  double getWeeklyAverage() {
    if (_weights.isEmpty) return 0.0;
    final lastWeights = _weights.length >= 7 ? _weights.sublist(_weights.length - 7) : _weights;
    return lastWeights.reduce((a, b) => a + b) / lastWeights.length;
  }

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    final style = TextStyle(fontSize: 10, color: Colors.black);
    int index = value.toInt();
    if (index < _dates.length) {
      return SideTitleWidget(
        axisSide: meta.axisSide,
        space: 4,
        child: Text(_dates[index], style: style),
      );
    }
    return const SizedBox.shrink();
  }

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    return Text(
      value.toInt().toString(),
      style: const TextStyle(fontSize: 12, color: Colors.black),
      textAlign: TextAlign.center,
    );
  }

  @override
  Widget build(BuildContext context) {
    final weeklyAvg = getWeeklyAverage();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تتبع الوزن'),
          backgroundColor: const Color(0xFF2CB191),
          elevation: 0,
          iconTheme: const IconThemeData(color: Colors.white),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Card(
                color: const Color(0xFFF0F9F7),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'أدخل وزنك الحالي'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: _addWeight,
                        child: const Text('إضافة'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2CB191),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              if (_weights.isNotEmpty)
                Column(
                  children: [
                    Card(
                      color: const Color(0xFFE1F5F1),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          'متوسط آخر ٧ أيام: ${weeklyAvg.toStringAsFixed(1)} كغ',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 280,
                      child: LineChart(
                        LineChartData(
                          titlesData: FlTitlesData(
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: bottomTitleWidgets,
                              ),
                            ),
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: leftTitleWidgets,
                                reservedSize: 32,
                                interval: 5,
                              ),
                            ),
                            rightTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            topTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                          ),
                          borderData: FlBorderData(
                            show: true,
                            border: const Border(
                              bottom: BorderSide(),
                              left: BorderSide(),
                            ),
                          ),
                          gridData: FlGridData(show: true),
                          lineBarsData: [
                            LineChartBarData(
                              spots: getChartData(),
                              isCurved: true,
                              barWidth: 3,
                              color: const Color(0xFF2CB191),
                              dotData: FlDotData(show: true),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _weights.length,
                      itemBuilder: (context, idx) {
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            leading: const Icon(Icons.monitor_weight, color: Color(0xFF2CB191)),
                            title: Text('${_weights[idx].toStringAsFixed(1)} كغ'),
                            subtitle: Text('تاريخ: ${_dates[idx]}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Colors.orange),
                                  onPressed: () => _showEditDialog(idx),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => _deleteWeight(idx),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                )
              else
                const Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Text('لم يتم إدخال أي أوزان بعد.'),
                ),
              const SizedBox(height: 18),
              // ----------- زر الإعلان في الأسفل -----------
              ElevatedButton(
                onPressed: _isRewardedAdLoaded ? _showRewardedAd : null,
                child: const Text('شاهد إعلان لدعم التطبيق'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2CB191),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
              // ---------------------------------------------
            ],
          ),
        ),
      ),
    );
  }
}
