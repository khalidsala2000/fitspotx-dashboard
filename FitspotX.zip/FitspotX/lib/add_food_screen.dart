import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

// كلاس الطعام الأساسي
class FoodEntry {
  final String mealType;
  final String foodName;
  final double quantity;
  final String unit;
  final double calories;
  final double protein;
  final double carbs;
  final double fats;
  final double saturatedFat;
  final double sugar;
  final double fiber;
  final double calcium;
  final double iron;
  final double magnesium;
  final double zinc;
  final double vitaminA;
  final double vitaminC;

  FoodEntry({
    required this.mealType,
    required this.foodName,
    required this.quantity,
    required this.unit,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fats,
    required this.saturatedFat,
    required this.sugar,
    required this.fiber,
    required this.calcium,
    required this.iron,
    required this.magnesium,
    required this.zinc,
    required this.vitaminA,
    required this.vitaminC,
  });

  Map<String, dynamic> toJson() => {
    'mealType': mealType,
    'foodName': foodName,
    'quantity': quantity,
    'unit': unit,
    'calories': calories,
    'protein': protein,
    'carbs': carbs,
    'fats': fats,
    'saturatedFat': saturatedFat,
    'sugar': sugar,
    'fiber': fiber,
    'calcium': calcium,
    'iron': iron,
    'magnesium': magnesium,
    'zinc': zinc,
    'vitaminA': vitaminA,
    'vitaminC': vitaminC,
  };

  factory FoodEntry.fromJson(Map<String, dynamic> json) => FoodEntry(
    mealType: json['mealType'],
    foodName: json['foodName'],
    quantity: (json['quantity'] ?? 0).toDouble(),
    unit: json['unit'] ?? 'غرام',
    calories: (json['calories'] ?? 0).toDouble(),
    protein: (json['protein'] ?? 0).toDouble(),
    carbs: (json['carbs'] ?? 0).toDouble(),
    fats: (json['fats'] ?? 0).toDouble(),
    saturatedFat: (json['saturatedFat'] ?? 0).toDouble(),
    sugar: (json['sugar'] ?? 0).toDouble(),
    fiber: (json['fiber'] ?? 0).toDouble(),
    calcium: (json['calcium'] ?? 0).toDouble(),
    iron: (json['iron'] ?? 0).toDouble(),
    magnesium: (json['magnesium'] ?? 0).toDouble(),
    zinc: (json['zinc'] ?? 0).toDouble(),
    vitaminA: (json['vitaminA'] ?? 0).toDouble(),
    vitaminC: (json['vitaminC'] ?? 0).toDouble(),
  );
}

// 2. قائمة الأطعمة foods (اختصرها أو زيد عليها حسب ما بدك، حطيت بس كم مثال!)
final List<Map<String, dynamic>> foods = [
{
'name': 'بيض مسلوق',
'calories': 1.43, // لكل 1غرام
'protein': 0.125,
'carbs': 0.01,
'fats': 0.1,
'saturatedFat': 0.032,
'sugar': 0.01,
'fiber': 0,
'calcium': 0.05,
'iron': 0.012,
'magnesium': 0.01,
'zinc': 0.011,
'vitaminA': 0.16,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'بيضة', 'factor': 50},
],
},
{
'name': 'موز',
'calories': 0.89,
'protein': 0.011,
'carbs': 0.23,
'fats': 0.003,
'saturatedFat': 0.001,
'sugar': 0.12,
'fiber': 0.026,
'calcium': 0.005,
'iron': 0.0003,
'magnesium': 0.0027,
'zinc': 0.00015,
'vitaminA': 0.0003,
'vitaminC': 0.0087,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 120},
],
},
{
'name': 'رز مطبوخ',
'calories': 1.3,
'protein': 0.026,
'carbs': 0.28,
'fats': 0.002,
'saturatedFat': 0,
'sugar': 0,
'fiber': 0.004,
'calcium': 0.001,
'iron': 0.0001,
'magnesium': 0.0005,
'zinc': 0.0004,
'vitaminA': 0,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'كوب', 'factor': 200},
],
},
{
'name': 'شوفان',
'calories': 3.8,
'protein': 0.13,
'carbs': 0.67,
'fats': 0.07,
'saturatedFat': 0.01,
'sugar': 0.01,
'fiber': 0.1,
'calcium': 0.05,
'iron': 0.005,
'magnesium': 0.012,
'zinc': 0.002,
'vitaminA': 0.000001,
'vitaminC': 0.0004,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'كوب', 'factor': 80},
],
},
{
'name': 'حليب بقري',
'calories': 0.65,
'protein': 0.033,
'carbs': 0.05,
'fats': 0.036,
'saturatedFat': 0.023,
'sugar': 0.05,
'fiber': 0,
'calcium': 0.12,
'iron': 0.0004,
'magnesium': 0.0011,
'zinc': 0.0004,
'vitaminA': 0.05,
'vitaminC': 0.001,
'units': [
{'label': 'مل (ملليلتر)', 'factor': 1},
{'label': 'كوب', 'factor': 240},
],
},
{
'name': 'تفاح',
'calories': 0.52,
'protein': 0.003,
'carbs': 0.14,
'fats': 0.002,
'saturatedFat': 0.001,
'sugar': 0.1,
'fiber': 0.024,
'calcium': 0.006,
'iron': 0.0001,
'magnesium': 0.001,
'zinc': 0.0004,
'vitaminA': 0.00054,
'vitaminC': 0.0046,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 150},
],
},
{
'name': 'دجاج مشوي',
'calories': 2.39,
'protein': 0.27,
'carbs': 0,
'fats': 0.14,
'saturatedFat': 0.04,
'sugar': 0,
'fiber': 0,
'calcium': 0.015,
'iron': 0.001,
'magnesium': 0.0024,
'zinc': 0.0021,
'vitaminA': 0.00013,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'صدر دجاج', 'factor': 150},
],
},
{
'name': 'بطاطا مسلوقة',
'calories': 0.87,
'protein': 0.019,
'carbs': 0.2,
'fats': 0.001,
'saturatedFat': 0,
'sugar': 0.001,
'fiber': 0.018,
'calcium': 0.005,
'iron': 0.0003,
'magnesium': 0.0023,
'zinc': 0.0003,
'vitaminA': 0.0001,
'vitaminC': 0.0197,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 90},
],
},
{
'name': 'لبن زبادي',
'calories': 0.61,
'protein': 0.035,
'carbs': 0.047,
'fats': 0.033,
'saturatedFat': 0.021,
'sugar': 0.047,
'fiber': 0,
'calcium': 0.12,
'iron': 0.0001,
'magnesium': 0.0011,
'zinc': 0.0004,
'vitaminA': 0.028,
'vitaminC': 0.001,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'علبة', 'factor': 125},
],
},
{
'name': 'جبنة بيضاء',
'calories': 2.64,
'protein': 0.14,
'carbs': 0.014,
'fats': 0.21,
'saturatedFat': 0.14,
'sugar': 0.01,
'fiber': 0,
'calcium': 0.48,
'iron': 0.0002,
'magnesium': 0.0011,
'zinc': 0.0032,
'vitaminA': 0.102,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'شريحة', 'factor': 30},
],
},
{
'name': 'سمك سلمون',
'calories': 2.06,
'protein': 0.20,
'carbs': 0,
'fats': 0.13,
'saturatedFat': 0.03,
'sugar': 0,
'fiber': 0,
'calcium': 0.009,
'iron': 0.0005,
'magnesium': 0.0029,
'zinc': 0.0006,
'vitaminA': 0.0005,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'شريحة', 'factor': 100},
],
},
{
'name': 'تونة معلبة',
'calories': 1.16,
'protein': 0.25,
'carbs': 0,
'fats': 0.01,
'saturatedFat': 0.002,
'sugar': 0,
'fiber': 0,
'calcium': 0.013,
'iron': 0.001,
'magnesium': 0.0032,
'zinc': 0.0005,
'vitaminA': 0,
'vitaminC': 0,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'علبة', 'factor': 140},
],
},
{
'name': 'عدس مطبوخ',
'calories': 1.16,
'protein': 0.09,
'carbs': 0.20,
'fats': 0.004,
'saturatedFat': 0.001,
'sugar': 0.002,
'fiber': 0.08,
'calcium': 0.0019,
'iron': 0.0033,
'magnesium': 0.0036,
'zinc': 0.0012,
'vitaminA': 0,
'vitaminC': 0.0012,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'كوب', 'factor': 198},
],
},
{
'name': 'حمص مسلوق',
'calories': 1.64,
'protein': 0.089,
'carbs': 0.27,
'fats': 0.028,
'saturatedFat': 0.003,
'sugar': 0.048,
'fiber': 0.08,
'calcium': 0.0049,
'iron': 0.0027,
'magnesium': 0.0048,
'zinc': 0.0016,
'vitaminA': 0,
'vitaminC': 0.0012,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'كوب', 'factor': 164},
],
},
{
'name': 'جوز عين الجمل',
'calories': 6.54,
'protein': 0.15,
'carbs': 0.14,
'fats': 0.65,
'saturatedFat': 0.006,
'sugar': 0.027,
'fiber': 0.067,
'calcium': 0.025,
'iron': 0.002,
'magnesium': 0.0131,
'zinc': 0.0031,
'vitaminA': 0,
'vitaminC': 0.001,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 8},
],
},
{
'name': 'بروكلي مسلوق',
'calories': 0.35,
'protein': 0.028,
'carbs': 0.07,
'fats': 0.004,
'saturatedFat': 0.001,
'sugar': 0.018,
'fiber': 0.034,
'calcium': 0.0047,
'iron': 0.0007,
'magnesium': 0.0021,
'zinc': 0.0004,
'vitaminA': 0.0003,
'vitaminC': 0.0649,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'زهرة', 'factor': 30},
],
},
{
'name': 'سبانخ طازجة',
'calories': 0.23,
'protein': 0.029,
'carbs': 0.036,
'fats': 0.003,
'saturatedFat': 0.001,
'sugar': 0.002,
'fiber': 0.022,
'calcium': 0.0099,
'iron': 0.0027,
'magnesium': 0.0079,
'zinc': 0.0005,
'vitaminA': 0.0469,
'vitaminC': 0.0281,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'كوب', 'factor': 30},
],
},
{
'name': 'جزر',
'calories': 0.41,
'protein': 0.009,
'carbs': 0.10,
'fats': 0.002,
'saturatedFat': 0.001,
'sugar': 0.048,
'fiber': 0.028,
'calcium': 0.0033,
'iron': 0.0003,
'magnesium': 0.0012,
'zinc': 0.0002,
'vitaminA': 0.083,
'vitaminC': 0.0059,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 60},
],
},
{
'name': 'تمر',
'calories': 2.77,
'protein': 0.018,
'carbs': 0.75,
'fats': 0.002,
'saturatedFat': 0.001,
'sugar': 0.63,
'fiber': 0.077,
'calcium': 0.0015,
'iron': 0.0009,
'magnesium': 0.0013,
'zinc': 0.0001,
'vitaminA': 0.0002,
'vitaminC': 0.0004,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 8},
],
},
{
'name': 'كوسا مطبوخة',
'calories': 0.17,
'protein': 0.012,
'carbs': 0.035,
'fats': 0.003,
'saturatedFat': 0.001,
'sugar': 0.024,
'fiber': 0.011,
'calcium': 0.0016,
'iron': 0.0002,
'magnesium': 0.0017,
'zinc': 0.0002,
'vitaminA': 0.0002,
'vitaminC': 0.0059,
'units': [
{'label': 'غرام', 'factor': 1},
{'label': 'حبة', 'factor': 120},
],
},
];
class AddFoodScreen extends StatefulWidget {
  const AddFoodScreen({super.key});
  @override
  State<AddFoodScreen> createState() => _AddFoodScreenState();
}

class _AddFoodScreenState extends State<AddFoodScreen> {
  String selectedMeal = 'فطور';
  String selectedUnit = 'غرام';
  int unitFactor = 1;
  Map<String, dynamic>? selectedFood;
  List<Map<String, dynamic>> currentUnits = [{'label': 'غرام', 'factor': 1}];

  final TextEditingController foodController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();

  double calories = 0, protein = 0, carbs = 0, fats = 0;
  double saturatedFat = 0, sugar = 0, fiber = 0;
  double calcium = 0, iron = 0, magnesium = 0, zinc = 0;
  double vitaminA = 0, vitaminC = 0;

  void fillMacrosByFood(String foodName) {
    final food = foods.firstWhere(
          (item) => item['name'] == foodName,
      orElse: () => {},
    );
    selectedFood = food.isNotEmpty ? food : null;
    if (selectedFood != null) {
      currentUnits = List<Map<String, dynamic>>.from(selectedFood!['units'] ?? [{'label': 'غرام', 'factor': 1}]);
      if (!currentUnits.any((u) => u['label'] == selectedUnit)) {
        selectedUnit = currentUnits.first['label'];
        unitFactor = currentUnits.first['factor'];
      }
    }
    double qty = double.tryParse(quantityController.text) ?? 0;
    double quantity = qty * unitFactor;
    if (selectedFood != null) {
      setState(() {
        calories     = quantity * (selectedFood!['calories']     ?? 0);
        protein      = quantity * (selectedFood!['protein']      ?? 0);
        carbs        = quantity * (selectedFood!['carbs']        ?? 0);
        fats         = quantity * (selectedFood!['fats']         ?? 0);
        saturatedFat = quantity * (selectedFood!['saturatedFat'] ?? 0);
        sugar        = quantity * (selectedFood!['sugar']        ?? 0);
        fiber        = quantity * (selectedFood!['fiber']        ?? 0);
        calcium      = quantity * (selectedFood!['calcium']      ?? 0);
        iron         = quantity * (selectedFood!['iron']         ?? 0);
        magnesium    = quantity * (selectedFood!['magnesium']    ?? 0);
        zinc         = quantity * (selectedFood!['zinc']         ?? 0);
        vitaminA     = quantity * (selectedFood!['vitaminA']     ?? 0);
        vitaminC     = quantity * (selectedFood!['vitaminC']     ?? 0);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    quantityController.addListener(() {
      fillMacrosByFood(foodController.text.trim());
    });
  }

  void addFoodToDay() async {
    final food = FoodEntry(
      mealType: selectedMeal,
      foodName: foodController.text.trim(),
      quantity: double.tryParse(quantityController.text) ?? 0,
      unit: selectedUnit,
      calories: calories,
      protein: protein,
      carbs: carbs,
      fats: fats,
      saturatedFat: saturatedFat,
      sugar: sugar,
      fiber: fiber,
      calcium: calcium,
      iron: iron,
      magnesium: magnesium,
      zinc: zinc,
      vitaminA: vitaminA,
      vitaminC: vitaminC,
    );

    final prefs = await SharedPreferences.getInstance();
    final List<String> saved = prefs.getStringList('foodEntries') ?? [];
    saved.add(jsonEncode(food.toJson()));
    await prefs.setStringList('foodEntries', saved);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تمت إضافة الطعام!')),
    );

    foodController.clear();
    quantityController.clear();
    setState(() {
      calories = protein = carbs = fats = 0;
      saturatedFat = sugar = fiber = 0;
      calcium = iron = magnesium = zinc = 0;
      vitaminA = vitaminC = 0;
      selectedFood = null;
      selectedUnit = 'غرام';
      unitFactor = 1;
      currentUnits = [{'label': 'غرام', 'factor': 1}];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'إضافة طعام',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم الرجوع أبيض
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            children: [
              const Text(
                'نوع الوجبة:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF192734),
                  fontSize: 16,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButton<String>(
                  value: selectedMeal,
                  dropdownColor: Colors.white,
                  style: const TextStyle(color: Color(0xFF192734), fontWeight: FontWeight.bold),
                  iconEnabledColor: const Color(0xFF2CB191),
                  underline: const SizedBox(),
                  borderRadius: BorderRadius.circular(12),
                  onChanged: (newValue) => setState(() => selectedMeal = newValue!),
                  items: ['فطور', 'غداء', 'عشاء', 'سناك']
                      .map((value) => DropdownMenuItem(
                    value: value,
                    child: Text(value, style: const TextStyle(color: Color(0xFF192734))),
                  ))
                      .toList(),
                ),
              ),
              const SizedBox(height: 18),
              Autocomplete<String>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  if (textEditingValue.text == '') return const Iterable<String>.empty();
                  return foods
                      .map((f) => f['name'] as String)
                      .where((option) => option.contains(textEditingValue.text.trim()));
                },
                onSelected: (String selection) {
                  foodController.text = selection;
                  fillMacrosByFood(selection);
                },
                fieldViewBuilder: (context, controller, focusNode, onEditingComplete) {
                  foodController.text = controller.text;
                  return TextField(
                    controller: controller,
                    focusNode: focusNode,
                    decoration: InputDecoration(
                      labelText: 'اسم الطعام',
                      labelStyle: const TextStyle(color: Color(0xFF2CB191)),
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onEditingComplete: onEditingComplete,
                    onChanged: (value) => fillMacrosByFood(value.trim()),
                    style: const TextStyle(color: Color(0xFF192734)),
                    textDirection: TextDirection.rtl,
                  );
                },
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: quantityController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'الكمية',
                        labelStyle: const TextStyle(color: Color(0xFF2CB191)),
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      style: const TextStyle(color: Color(0xFF192734)),
                      textDirection: TextDirection.rtl,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF2CB191), width: 1),
                    ),
                    child: DropdownButton<String>(
                      value: selectedUnit,
                      onChanged: (val) {
                        setState(() {
                          selectedUnit = val!;
                          if (selectedFood != null) {
                            final unitObj = currentUnits.firstWhere((u) => u['label'] == selectedUnit, orElse: () => {'factor': 1});
                            unitFactor = unitObj['factor'] ?? 1;
                          } else {
                            unitFactor = 1;
                          }
                          fillMacrosByFood(foodController.text.trim());
                        });
                      },
                      underline: const SizedBox(),
                      icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF2CB191)),
                      items: currentUnits.map((unit) {
                        return DropdownMenuItem<String>(
                          value: unit['label'],
                          child: Text(unit['label']),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text('إضافة للطعام', style: TextStyle(color: Colors.white)),
                  onPressed: addFoodToDay,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2CB191),
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),

              const SizedBox(height: 25),

              Card(
                color: Colors.white,
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('القيم الغذائية:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
                      const SizedBox(height: 10),
                      GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 6,
                          crossAxisSpacing: 6,
                          childAspectRatio: 1.25,
                        ),
                        children: [
                          _macroCard('السعرات الحرارية', calories, 'س.ح', color: Colors.teal.shade50),
                          _macroCard('البروتين', protein, 'غ', color: Colors.blue.shade50),
                          _macroCard('الكارب', carbs, 'غ', color: Colors.orange.shade50),
                          _macroCard('دهون', fats, 'غ', color: Colors.pink.shade50),
                          _macroCard('دهون مشبعة', saturatedFat, 'غ'),
                          _macroCard('سكر', sugar, 'غ'),
                          _macroCard('ألياف', fiber, 'غ'),
                          _macroCard('كالسيوم', calcium, 'ملغ'),
                          _macroCard('حديد', iron, 'ملغ'),
                          _macroCard('مغنيسيوم', magnesium, 'ملغ'),
                          _macroCard('زنك', zinc, 'ملغ'),
                          _macroCard('فيتامين A', vitaminA, 'م.غ'),
                          _macroCard('فيتامين C', vitaminC, 'ملغ'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _macroCard(String label, double value, String unit, {Color? color}) {
    return Container(
      decoration: BoxDecoration(
        color: color ?? Colors.grey.shade100,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF2CB191).withOpacity(0.15), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.07),
            blurRadius: 3,
            offset: const Offset(1, 2),
          )
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 2),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: Color(0xFF192734))),
          const SizedBox(height: 2),
          Text(
            value.toStringAsFixed(1),
            style: const TextStyle(
              fontSize: 16,
              color: Color(0xFF2CB191),
              fontWeight: FontWeight.bold,
              height: 1.1,
            ),
          ),
          Text(unit, style: const TextStyle(fontSize: 9, color: Colors.grey)),
        ],
      ),
    );
  }
}