import 'package:flutter/material.dart';
import 'package:pedometer/pedometer.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class StepCounterScreen extends StatefulWidget {
  const StepCounterScreen({Key? key}) : super(key: key);

  @override
  State<StepCounterScreen> createState() => _StepCounterScreenState();
}

class _StepCounterScreenState extends State<StepCounterScreen> {
  StreamSubscription<StepCount>? _stepCountStream;
  int _steps = 0;
  final int _dailyGoal = 10000;
  Map<String, int> stepsHistory = {};
  double userWeight = 75;

  // إعلان بانر
  BannerAd? _bannerAd;

  // قائمة الإنجازات المشوقة
  final List<Map<String, dynamic>> achievements = [
    {
      'km': 1,
      'title': 'جولة حول المنزل!',
      'desc': 'قطعت أول كيلومتر – جولة كاملة حول المنزل.',
      'icon': Icons.directions_walk,
    },
    {
      'km': 5,
      'title': 'عدّاء صغير!',
      'desc': 'مشيت 5 كم – يعادل تقريبًا طريق سريع داخل المدينة!',
      'icon': Icons.directions_run,
    },
    {
      'km': 10,
      'title': 'عمق الأرض!',
      'desc': '10 كم – قطعت مسافة تعادل أعمق نقطة معروفة على سطح الأرض (خندق ماريانا)!',
      'icon': Icons.emoji_events,
    },
    {
      'km': 20,
      'title': 'نصف ماراثون',
      'desc': '20 كم – وصلت لنصف ماراثون كامل! إنجاز رياضي رهيب وبتقرب تصير ماراثوني حقيقي!',
      'icon': Icons.water,
    },
    {
      'km': 42,
      'title': 'ماراثون كامل!',
      'desc': 'قطعت 42 كم – مبروك ماراثون كامل!',
      'icon': Icons.flag,
    },
    {
      'km': 100,
      'title': 'سفاري المسافات!',
      'desc': '100 كم – مسافة مشي رهيبة!',
      'icon': Icons.map,
    },
    {
      'km': 500,
      'title': 'رحالة بين المدن!',
      'desc': '500 كم – مشيت كأنك سافرت بين عدة مدن.',
      'icon': Icons.travel_explore,
    },
    {
      'km': 1000,
      'title': 'وصلت الألف!',
      'desc': '1000 كم – مسافة توصلك للحدود. مبروك الإنجاز القوي!',
      'icon': Icons.directions_bike,
    },
    {
      'km': 2000,
      'title': 'رحلة العمر!',
      'desc': '2000 كم – قطعت مسافة تعادل المشي من دمشق لحدود أوروبا!',
      'icon': Icons.public,
    },
    {
      'km': 3000,
      'title': 'رحلة القارات!',
      'desc': '3,000 كم – قطعت المسافة من الزقازيق (مصر) إلى فولفسبورغ (ألمانيا)!',
      'icon': Icons.directions_car
    },
    {
      'km': 5000,
      'title': 'مستكشف الكواكب!',
      'desc': '5000 كم – لو كنت على سطح القمر لأكملت عشر جولات كاملة حوله!',
      'icon': Icons.rocket_launch,
    },
  ];

  Set<int> unlockedAchievements = {};

  @override
  void initState() {
    super.initState();
    loadStepsHistory();
    _loadWeight();
    _loadAchievements();
    initPedometer();

    // تهيئة إعلان بانر
    _bannerAd = BannerAd(
adUnitId: 'ca-app-pub-3940256099942544/6300978111', // هذا الـ test ID الرسمي من Google للبانر
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(),
    )..load();
  }

  @override
  void dispose() {
    _stepCountStream?.cancel();
    _bannerAd?.dispose();
    super.dispose();
  }

  // --- حساب الوزن الحالي من SharedPreferences ---
  Future<void> _loadWeight() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userWeight = prefs.getDouble('currentWeight') ?? 75;
    });
  }

  // --- حساب المسافة على أساس الخطوة 0.78 متر (متوسط بالغ) ---
  double getDistanceKm(int steps) => (steps * 0.78) / 1000;

  // --- حساب مجموع الكيلومترات لكل الأيام ---
  double get totalKmWalked {
    double total = 0;
    stepsHistory.values.forEach((s) => total += getDistanceKm(s));
    return total;
  }

  // --- حساب السعرات المحروقة (تقريبية) ---
  double getCaloriesBurned(int steps) {
    // السعرات لكل خطوة = (0.57 * الوزن كغ) / 1000 خطوة تقريباً
    return ((0.57 * userWeight) * (steps / 1000));
  }

  // --- تحميل إنجازات تم فتحها ---
  Future<void> _loadAchievements() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      unlockedAchievements =
          (prefs.getStringList('achievements') ?? []).map((e) => int.parse(e)).toSet();
    });
  }

  // --- حفظ الإنجازات المفتوحة ---
  Future<void> _saveAchievements() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        'achievements', unlockedAchievements.map((e) => e.toString()).toList());
  }

  // --- تحميل سجل الخطوات ---
  Future<void> loadStepsHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final allKeys = prefs.getKeys().where((k) => k.startsWith('steps_'));
    Map<String, int> history = {};
    for (var k in allKeys) {
      final value = prefs.getInt(k) ?? 0;
      history[k.substring(6)] = value;
    }
    setState(() {
      stepsHistory = history;
      String today = DateTime.now().toIso8601String().substring(0, 10);
      if (history.containsKey(today)) {
        _steps = history[today]!;
      }
    });
  }

  void initPedometer() {
    _stepCountStream = Pedometer.stepCountStream.listen(
      onStepCount,
      onError: onStepCountError,
      cancelOnError: true,
    );
  }

  void onStepCount(StepCount event) async {
    setState(() {
      _steps = event.steps;
    });
    final prefs = await SharedPreferences.getInstance();
    String today = DateTime.now().toIso8601String().substring(0, 10);
    await prefs.setInt('steps_$today', event.steps);

    setState(() {
      stepsHistory[today] = event.steps;
    });

    checkAndShowAchievements();
  }

  void onStepCountError(error) {
    setState(() {
      _steps = 0;
    });
  }

  // --- دالة الإنجازات والتحفيز ---
  void checkAndShowAchievements() async {
    double totalKm = totalKmWalked;
    for (int i = 0; i < achievements.length; i++) {
      final a = achievements[i];
      if (totalKm >= a['km'] && !unlockedAchievements.contains(i)) {
        unlockedAchievements.add(i);
        await _saveAchievements();
        if (mounted) {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: Row(
                children: [
                  Icon(a['icon'], color: Color(0xFF2CB191), size: 32),
                  const SizedBox(width: 10),
                  Text('إنجاز جديد!', style: TextStyle(color: Color(0xFF2CB191))),
                ],
              ),
              content: Text('${a['title']}\n\n${a['desc']}'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('رهيب!'),
                ),
              ],
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    double progress = (_steps / _dailyGoal).clamp(0.0, 1.0);

    double todayKm = getDistanceKm(_steps);
    double todayCalories = getCaloriesBurned(_steps);

    final sortedDays = stepsHistory.keys.toList()..sort((a, b) => b.compareTo(a));

    WidgetsBinding.instance.addPostFrameCallback((_) => checkAndShowAchievements());
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          iconTheme: const IconThemeData(color: Colors.white),
          title: const Text(
            'عداد الخطوات',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Icon(Icons.directions_walk, size: 80, color: Colors.teal),
              const SizedBox(height: 10),
              Text(
                'عدد الخطوات اليوم: $_steps',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                'المسافة: ${todayKm.toStringAsFixed(2)} كم',
                style: const TextStyle(fontSize: 16),
              ),
              Text(
                'السعرات المحروقة: ${todayCalories.toStringAsFixed(0)} سعرة حرارية',
                style: const TextStyle(fontSize: 16, color: Color(0xFF2CB191)),
              ),
              const SizedBox(height: 24),
              LinearProgressIndicator(
                value: progress,
                minHeight: 16,
                backgroundColor: Colors.grey[300],
                color: Colors.teal,
              ),
              const SizedBox(height: 10),
              Text('${(progress * 100).toStringAsFixed(1)}% من الهدف اليومي'),
              const SizedBox(height: 28),
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                color: const Color(0xFFE1F5F1),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Text(
                        'مجموع المسافة التي مشيتها:',
                        style: TextStyle(fontSize: 16, color: Colors.teal[900], fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${totalKmWalked.toStringAsFixed(2)} كم',
                        style: const TextStyle(fontSize: 20, color: Color(0xFF2CB191), fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Divider(),
              const Text(
                'سجل الأيام السابقة:',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF2CB191)),
              ),
              const SizedBox(height: 6),
              Expanded(
                child: sortedDays.isEmpty
                    ? const Center(child: Text('لا يوجد سجل خطوات محفوظ بعد.'))
                    : ListView.builder(
                  itemCount: sortedDays.length,
                  itemBuilder: (context, idx) {
                    String date = sortedDays[idx];
                    int count = stepsHistory[date]!;
                    double dayKm = getDistanceKm(count);
                    double dayCalories = getCaloriesBurned(count);
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      child: ListTile(
                        leading: const Icon(Icons.calendar_today, color: Colors.teal),
                        title: Text('التاريخ: $date'),
                        subtitle: Text(
                            'خطوات: $count\nمسافة: ${dayKm.toStringAsFixed(2)} كم\nسعرات: ${dayCalories.toStringAsFixed(0)}'),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              const Divider(),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'إنجازاتك:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Color(0xFF2CB191)),
                ),
              ),
              SizedBox(
                height: 72,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: achievements.asMap().entries.map((entry) {
                    int idx = entry.key;
                    var a = entry.value;
                    bool unlocked = unlockedAchievements.contains(idx);
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        children: [
                          CircleAvatar(
                            backgroundColor: unlocked ? Color(0xFF2CB191) : Colors.grey[300],
                            child: Icon(a['icon'], color: unlocked ? Colors.white : Colors.grey, size: 26),
                            radius: 22,
                          ),
                          SizedBox(height: 3),
                          Text(
                            a['title'],
                            style: TextStyle(
                              fontSize: 10,
                              color: unlocked ? Color(0xFF2CB191) : Colors.grey,
                              fontWeight: unlocked ? FontWeight.bold : FontWeight.normal,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
              // إعلان بانر بأسفل الشاشة
              if (_bannerAd != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: SizedBox(
                    width: _bannerAd!.size.width.toDouble(),
                    height: _bannerAd!.size.height.toDouble(),
                    child: AdWidget(ad: _bannerAd!),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}