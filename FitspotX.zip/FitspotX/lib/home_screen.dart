import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'calorie_tracker_screen.dart';
import 'add_food_screen.dart';
import 'step_counter_screen.dart';
import 'meals_screen.dart';
import 'weight_tracker_screen.dart';
import 'goals_screen.dart';
import 'about_screen.dart';
import 'contact_screen.dart';
import 'privacy_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  RewardedAd? _rewardedAd;

  @override
  void initState() {
    super.initState();
    _loadRewardedAd();
  }

  void _loadRewardedAd() {
    RewardedAd.load(
adUnitId: 'ca-app-pub-3940256099942544/5224354917', // هذا هو ID الإعلان التجريبي للمكافأة من Google
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
        },
        onAdFailedToLoad: (error) {
          print('فشل تحميل الإعلان: $error');
        },
      ),
    );
  }

  void _showRewardedAd() {
    if (_rewardedAd != null) {
      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('شكرًا على دعمك')),
          );
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الإعلان غير جاهز بعد')),
      );
    }
  }

  @override
  void dispose() {
    _rewardedAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F9FA),
        appBar: AppBar(
          title: const Text(
            'FitspotX',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Tajawal',
              fontWeight: FontWeight.bold,
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          backgroundColor: const Color(0xFF2CB191),
          elevation: 0,
          iconTheme: const IconThemeData(
            color: Colors.white,
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF2CB191),
                ),
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: Text(
                    'FitspotX',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Tajawal',
                    ),
                    textDirection: TextDirection.rtl,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'نسخة التطبيق: 1.0.0',
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontSize: 14,
                      fontFamily: 'Tajawal',
                    ),
                    textDirection: TextDirection.rtl,
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.home, color: Color(0xFF2CB191)),
                title: const Text('الرئيسية',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(fontFamily: 'Tajawal')),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading:
                    const Icon(Icons.info_outline, color: Color(0xFF2CB191)),
                title: const Text('حول التطبيق',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(fontFamily: 'Tajawal')),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AboutScreen()),
                  );
                },
              ),
              ListTile(
                leading:
                    const Icon(Icons.contact_mail, color: Color(0xFF2CB191)),
                title: const Text('اتصل بنا',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(fontFamily: 'Tajawal')),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ContactScreen()),
                  );
                },
              ),
              ListTile(
                leading:
                    const Icon(Icons.privacy_tip, color: Color(0xFF2CB191)),
                title: const Text('سياسة الخصوصية',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(fontFamily: 'Tajawal')),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PrivacyScreen()),
                  );
                },
              ),
            ],
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            children: [
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 22,
                  crossAxisSpacing: 22,
                  children: [
                    DashboardButton(
                      label: 'تتبع السعرات',
                      icon: Icons.track_changes,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const CalorieTrackerScreen()),
                        );
                      },
                    ),
                    DashboardButton(
                      label: 'إضافة طعام',
                      icon: Icons.fastfood,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const AddFoodScreen()),
                        );
                      },
                    ),
                    DashboardButton(
                      label: 'الوجبات المحسوبة',
                      icon: Icons.list_alt,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const MealsScreen()),
                        );
                      },
                    ),
                    DashboardButton(
                      label: 'تتبع الوزن',
                      icon: Icons.monitor_weight,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const WeightTrackerScreen()),
                        );
                      },
                    ),
                 DashboardButton(
  label: 'عداد الخطوات',
  icon: Icons.directions_walk,
  onPressed: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const StepCounterScreen(),
      ),
    );
  },
),



                    DashboardButton(
                      label: 'أهدافي',
                      icon: Icons.flag,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const GoalsScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _showRewardedAd,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2CB191),
                  foregroundColor: Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  textStyle: const TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 16,
                      fontWeight: FontWeight.bold),
                ),
                child: const Text('شاهد إعلان لدعم التطبيق'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onPressed;

  const DashboardButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF192734),
            width: 1.1,
          ),
        ),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: const Color(0xFF2CB191)),
            const SizedBox(height: 12),
            Text(
              label,
              style: const TextStyle(
                fontSize: 16,
                color: Color(0xFF2CB191),
                fontWeight: FontWeight.bold,
                fontFamily: 'Tajawal',
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
