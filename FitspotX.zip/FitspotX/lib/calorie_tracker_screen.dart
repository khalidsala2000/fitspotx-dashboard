import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'food_entry.dart';

class CalorieTrackerScreen extends StatefulWidget {
  const CalorieTrackerScreen({super.key});

  @override
  State<CalorieTrackerScreen> createState() => _CalorieTrackerScreenState();
}

class _CalorieTrackerScreenState extends State<CalorieTrackerScreen> {
  List<FoodEntry> localEntries = [];
  double calorieTarget = 2200;
  double weight = 75;

  // القيم العالمية للمغذيات (نفس كودك)
  final double proteinPerKg = 1.6;
  final double calciumRDA = 1000;
  final double magnesiumRDA = 400;
  final double ironRDA = 18;
  final double zincRDA = 11;
  final double vitaminARDA = 900;
  final double vitaminCRDA = 90;
  final double carbsRDA = 320;
  final double fatsRDA = 70;
  final double sugarRDA = 36;
  final double fiberRDA = 30;

  @override
  void initState() {
    super.initState();
    _loadSavedEntries();
    _loadGoals();
  }

  Future<void> _loadSavedEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> saved = prefs.getStringList('foodEntries') ?? [];
    setState(() {
      localEntries = saved.map((e) => FoodEntry.fromJson(jsonDecode(e))).toList();
    });
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> encoded = localEntries.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList('foodEntries', encoded);
  }

  Future<void> _loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      calorieTarget = prefs.getDouble('calorieTarget') ?? 2200;
      weight = prefs.getDouble('currentWeight') ?? 75;
    });
  }

  double totalFor(double Function(FoodEntry entry) calc) {
    return localEntries.fold(0, (sum, entry) => sum + calc(entry));
  }

  double _getMacroPercent(double total, double target) {
    if (target == 0) return 0;
    return (total / target).clamp(0.0, 2.0);
  }

  Color _progressColor(double percent) {
    if (percent >= 0.95 && percent <= 1.2) {
      return Colors.green.shade700;
    } else if (percent >= 0.7) {
      return Colors.orange;
    } else {
      return const Color(0xFF192734);
    }
  }

  void editMealDialog(int index) {
    final meal = localEntries[index];
    final TextEditingController nameController = TextEditingController(text: meal.foodName);
    final TextEditingController quantityController = TextEditingController(text: meal.quantity.toString());
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعديل الوجبة'),
        content: Directionality(
          textDirection: TextDirection.rtl,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'اسم الطعام'),
                readOnly: true,
              ),
              TextField(
                controller: quantityController,
                decoration: InputDecoration(labelText: 'الكمية (${meal.unit})'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: const Text('إلغاء'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          ElevatedButton(
            child: const Text('حفظ'),
            onPressed: () async {
              setState(() {
                localEntries[index] = FoodEntry(
                  mealType: meal.mealType,
                  foodName: meal.foodName,
                  quantity: double.tryParse(quantityController.text) ?? meal.quantity,
                  unit: meal.unit,
                  calories: meal.calories,
                  protein: meal.protein,
                  carbs: meal.carbs,
                  fats: meal.fats,
                  saturatedFat: meal.saturatedFat,
                  sugar: meal.sugar,
                  fiber: meal.fiber,
                  calcium: meal.calcium,
                  iron: meal.iron,
                  magnesium: meal.magnesium,
                  zinc: meal.zinc,
                  vitaminA: meal.vitaminA,
                  vitaminC: meal.vitaminC,
                );
              });
              await _saveEntries();
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalCalories = totalFor((e) => e.calories);
    final totalProtein = totalFor((e) => e.protein);
    final totalCarbs = totalFor((e) => e.carbs);
    final totalFats = totalFor((e) => e.fats);
    final totalSaturatedFat = totalFor((e) => e.saturatedFat);
    final totalSugar = totalFor((e) => e.sugar);
    final totalFiber = totalFor((e) => e.fiber);
    final totalCalcium = totalFor((e) => e.calcium);
    final totalIron = totalFor((e) => e.iron);
    final totalMagnesium = totalFor((e) => e.magnesium);
    final totalZinc = totalFor((e) => e.zinc);
    final totalVitaminA = totalFor((e) => e.vitaminA);
    final totalVitaminC = totalFor((e) => e.vitaminC);

    final double proteinTarget = (weight * proteinPerKg).ceilToDouble();

    final macroPercents = [
      {
        'label': 'السعرات الحرارية',
        'total': totalCalories,
        'target': calorieTarget,
        'unit': 'سعرة حرارية',
        'percent': _getMacroPercent(totalCalories, calorieTarget),
      },
      {
        'label': 'البروتين',
        'total': totalProtein,
        'target': proteinTarget,
        'unit': 'غ',
        'percent': _getMacroPercent(totalProtein, proteinTarget),
      },
      {
        'label': 'الكربوهيدرات',
        'total': totalCarbs,
        'target': carbsRDA,
        'unit': 'غ',
        'percent': _getMacroPercent(totalCarbs, carbsRDA),
      },
      {
        'label': 'الدهون',
        'total': totalFats,
        'target': fatsRDA,
        'unit': 'غ',
        'percent': _getMacroPercent(totalFats, fatsRDA),
      },
      {
        'label': 'السكر',
        'total': totalSugar,
        'target': sugarRDA,
        'unit': 'غ',
        'percent': _getMacroPercent(totalSugar, sugarRDA),
      },
      {
        'label': 'الألياف',
        'total': totalFiber,
        'target': fiberRDA,
        'unit': 'غ',
        'percent': _getMacroPercent(totalFiber, fiberRDA),
      },
      {
        'label': 'الكالسيوم',
        'total': totalCalcium,
        'target': calciumRDA,
        'unit': 'ملغ',
        'percent': _getMacroPercent(totalCalcium, calciumRDA),
      },
      {
        'label': 'مغنيسيوم',
        'total': totalMagnesium,
        'target': magnesiumRDA,
        'unit': 'ملغ',
        'percent': _getMacroPercent(totalMagnesium, magnesiumRDA),
      },
      {
        'label': 'حديد',
        'total': totalIron,
        'target': ironRDA,
        'unit': 'ملغ',
        'percent': _getMacroPercent(totalIron, ironRDA),
      },
      {
        'label': 'زنك',
        'total': totalZinc,
        'target': zincRDA,
        'unit': 'ملغ',
        'percent': _getMacroPercent(totalZinc, zincRDA),
      },
      {
        'label': 'فيتامين A',
        'total': totalVitaminA,
        'target': vitaminARDA,
        'unit': 'م.غ',
        'percent': _getMacroPercent(totalVitaminA, vitaminARDA),
      },
      {
        'label': 'فيتامين C',
        'total': totalVitaminC,
        'target': vitaminCRDA,
        'unit': 'ملغ',
        'percent': _getMacroPercent(totalVitaminC, vitaminCRDA),
      },
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F9FA),
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'ملخص التغذية اليومي',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم الرجوع أبيض موحد
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: localEntries.isEmpty
              ? const Center(
            child: Text(
              'لا توجد أطعمة مضافة بعد.',
              style: TextStyle(color: Color(0xFF192734), fontSize: 18),
            ),
          )
              : SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'معدّل تحقيق أهدافك اليومية:',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF192734)),
                ),
                const SizedBox(height: 10),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Color(0xFF192734), width: 1.1),
                  ),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: macroPercents.map((macro) {
                      return _macroProgress(
                        macro['label'] as String,
                        macro['total'] as double,
                        macro['target'] as double,
                        macro['unit'] as String,
                        macro['percent'] as double,
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(thickness: 1.2, color: Color(0xFF192734)),
                const SizedBox(height: 10),
                const Text(
                  'تفاصيل الوجبات:',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF192734)),
                ),
                const SizedBox(height: 10),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: localEntries.length,
                  itemBuilder: (context, index) {
                    final meal = localEntries[index];
                    return Card(
                      elevation: 1,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(color: Color(0xFF2CB191), width: 1),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.restaurant, color: Color(0xFF2CB191)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    '${meal.foodName} - ${meal.quantity} ${meal.unit}',
                                    style: const TextStyle(
                                      color: Color(0xFF192734),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red, size: 28),
                                  onPressed: () async {
                                    setState(() => localEntries.removeAt(index));
                                    await _saveEntries();
                                  },
                                  tooltip: 'حذف الوجبة',
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text('الوجبة: ${meal.mealType}', style: const TextStyle(color: Colors.black54, fontSize: 13)),
                            const SizedBox(height: 8),
                            Divider(color: Colors.grey.shade300),
                            Wrap(
                              spacing: 10,
                              runSpacing: 8,
                              children: [
                                _miniMacro('سعرات حرارية', meal.calories, 'سعرة حرارية'),
                                _miniMacro('بروتين', meal.protein, 'غ'),
                                _miniMacro('كارب', meal.carbs, 'غ'),
                                _miniMacro('دهون', meal.fats, 'غ'),
                                _miniMacro('مشبعة', meal.saturatedFat, 'غ'),
                                _miniMacro('سكر', meal.sugar, 'غ'),
                                _miniMacro('ألياف', meal.fiber, 'غ'),
                                _miniMacro('كالسيوم', meal.calcium, 'ملغ'),
                                _miniMacro('حديد', meal.iron, 'ملغ'),
                                _miniMacro('مغنيسيوم', meal.magnesium, 'ملغ'),
                                _miniMacro('زنك', meal.zinc, 'ملغ'),
                                _miniMacro('A', meal.vitaminA, 'م.غ'),
                                _miniMacro('C', meal.vitaminC, 'ملغ'),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _macroProgress(String label, double value, double target, String unit, double percent) {
    final percentVal = (percent * 100).clamp(0, 200).toStringAsFixed(0);
    final color = _progressColor(percent);

    String statusText;
    Color statusColor;
    String? suggestion;

    if (percent < 0.8) {
      statusText = "أقل من المطلوب";
      statusColor = const Color(0xFF192734);
      suggestion = _macroSuggestion(label);
    } else if (percent <= 1.1) {
      statusText = "ضمن الهدف";
      statusColor = Colors.green.shade700;
      suggestion = null;
    } else {
      statusText = "تجاوزت الحد!";
      statusColor = Colors.orange;
      suggestion = null;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2CB191))),
              const SizedBox(width: 10),
              Text(
                '${value.toStringAsFixed(1)} / ${target.toStringAsFixed(0)} $unit  (${percentVal}%)',
                style: TextStyle(color: color, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(
            value: percent > 1.0 ? 1.0 : percent,
            backgroundColor: Colors.grey.shade300,
            minHeight: 10,
            color: color,
          ),
          const SizedBox(height: 3),
          Text(
            statusText,
            style: TextStyle(
              color: statusColor,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
          if (suggestion != null)
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text(
                'جرّب تناول: $suggestion',
                style: const TextStyle(
                  color: Color(0xFF2CB191),
                  fontWeight: FontWeight.w500,
                  fontSize: 13,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // دالة اقتراح الطعام حسب المغذي:
  String _macroSuggestion(String macro) {
    switch (macro) {
      case 'البروتين':
        return 'بيض مسلوق أو صدر دجاج';
      case 'الكالسيوم':
        return 'لبن زبادي أو جبنة بيضاء';
      case 'مغنيسيوم':
        return 'موز أو سبانخ';
      case 'حديد':
        return 'عدس أو سبانخ أو كبدة دجاج';
      case 'زنك':
        return 'لحمة أو مكسرات';
      case 'فيتامين A':
        return 'جزر أو بطاطا حلوة';
      case 'فيتامين C':
        return 'برتقال أو فليفلة';
      case 'الكربوهيدرات':
        return 'شوفان أو رز أو بطاطا';
      case 'الدهون':
        return 'زيت زيتون أو مكسرات أو أفوكادو';
      case 'الألياف':
        return 'بروكلي أو خس أو شوفان';
      case 'السكر':
        return 'حاول تقليل مصادر السكر المضاف';
      case 'السعرات الحرارية':
        return 'إضافة وجبة أو سناك غني بالطاقة';
      default:
        return 'مصدر غني بـ $macro';
    }
  }

  Widget _miniMacro(String label, double value, String unit) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFeaf8f5),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        '$label: ${value.toStringAsFixed(1)} $unit',
        style: const TextStyle(color: Color(0xFF192734), fontWeight: FontWeight.w500, fontSize: 13),
      ),
    );
  }
}
