import 'package:flutter/material.dart';

class ContactScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF2CB191),
          title: const Text(
            'اتصل بنا',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Tajawal',
              fontSize: 22,
            ),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(
            color: Colors.white, // سهم الرجوع أبيض
          ),
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Center(
            child: Text(
              'حابب تتواصل معنا؟\n\nراسلنا مباشرة عبر البريد:\nfitspotx@gmail.com\n\nأو زور موقعنا لأي استفسار أو اقتراح.',
              style: const TextStyle(
                fontSize: 18,
                fontFamily: 'Tajawal',
                color: Color(0xFF192734),
                height: 1.7,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}
