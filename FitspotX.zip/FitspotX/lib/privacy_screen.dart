import 'package:flutter/material.dart';

class PrivacyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF2CB191),
        title: const Text(
          'سياسة الخصوصية',
          textDirection: TextDirection.rtl,
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Text(
            'خصوصيتك أمانة.\n\nلا نقوم بمشاركة أي بيانات خاصة بك مع أي طرف ثالث. كل معلوماتك تبقى سرية وتُستخدم فقط لتحسين تجربتك داخل التطبيق.\n\nلمزيد من التفاصيل راجع سياسة الخصوصية الكاملة على موقعنا.',
            style: TextStyle(
              fontSize: 18,
              fontFamily: 'Tajawal',
            ),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
